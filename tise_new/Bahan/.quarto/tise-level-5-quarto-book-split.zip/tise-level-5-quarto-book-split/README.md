# Buku DNA TISE level 5 - Proyek Quarto

## Struktur
- `index.qmd`: prakata dan abstrak
- `chapters/`: part dan bab utama
- `appendices/`: lampiran teknis
- `references.bib`: bibliografi

## Render
```bash
quarto render
```

Untuk PDF, pastikan dependensi LaTeX/Typst tersedia di lingkungan Anda.
