// #import "@preview/bookly:3.0.0": *
#import "../../src/bookly.typ": *
// #show: chapter.with(title: "First chapter")

= First chapter
#lorem(100)
#minitoc
#pagebreak()

== Goals

#lorem(100)#context if states.tufte.get() [
  #note(lorem(10))
] else [
  #footnote(lorem(10))
]

Equations @eq:1 et @eq:2 are very important.
$
integral_0^1 f(x) dif x = F(1) - F(0) "et voilà"
$ <eq:1>

$
integral_0^1 f(x) dif x = F(1) - F(0) "et voilà"
$ <eq:2>

#lorem(20)
== Code

#context if states.tufte.get() [
  Figure @fig:1 is a beautiful typst logo.

  #notefigure(
    image("../images/typst-logo.svg"),
    caption: [#ls-caption([#lorem(10)], [#lorem(2)])],
    alignment: "baseline"
  )<fig:1>
]

#lorem(50)

Figure @fig:subfig shows the Typst logo. Figure @b is a Typst logo.
#subfigure(
figure(image("../images/typst-logo.svg"), caption: []),
figure(image("../images/typst-logo.svg"), caption: []), <b>,
columns: (1fr, 1fr),
caption: [(a) Left image and (b) Right image],
label: <fig:subfig>,
)

#lorem(50)
#figure(
  table(
    columns: 3,
    table.header(
      [Substance],
      [Subcritical °C],
      [Supercritical °C],
    ),
    [Hydrochloric Acid],
    [12.0], [92.1],
    [Sodium Myreth Sulfate],
    [16.6], [104],
    [Potassium Hydroxide],
    table.cell(colspan: 2)[24.7],
  ), caption: [#lorem(4)]
)

== Boxes

#context if states.tufte.get() [
  #lorem(50) #notecite(<Smi21>)
] else [
  #lorem(50) @Smi21
]

=== Informations

#info-box[
  #lorem(10)
]

#tip-box[
  #lorem(10)
]

#warning-box[
  #lorem(10)
]

#important-box[
  #lorem(10)
]

#proof-box[
  #lorem(10)
]

#pagebreak()
#question-box[
  #lorem(10)
]